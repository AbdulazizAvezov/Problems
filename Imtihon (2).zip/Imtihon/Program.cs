﻿using Imtihon;
using System.ComponentModel.Design;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;

public class Program
{
  
    public static void Main(string[] args)
    {
     
    
    }
}
